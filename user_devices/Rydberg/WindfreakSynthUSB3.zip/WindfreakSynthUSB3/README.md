# Explanation

This contains the code to talk to the Agilent 33250A arbitrary waveform generator over GPIB or RS232. Make sure you have the AWG configured so that the settings match what you're trying in python ("Utility" settings on the AWG)

There is also an example file TestCommRS232Example.py intended for testing the communication between python and the AWG outside of labscript using RS232.

Jk, this is acually for the windfreak RF signal generator